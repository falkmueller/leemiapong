<?php 
/*
 * Aufz�hlung aller m�glichen Spielst�nde
 */
class statusEnum {
	public static $STATUS_LOGIN = 'login';
	public static $STATUS_READY = 'ready';
	public static $STATUS_STARTED = 'started';
	public static $STATUS_FINISHED = 'finished';
}