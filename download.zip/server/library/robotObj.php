<?php 
/*
 * Objekt welches in der Session gehalten wird und Informationen des Robots enth�lt
 */
class robotObj {
	
	public $secret;
	public $side;
	public $nextH;
	
}