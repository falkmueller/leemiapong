AUTOR:
Falk M�ller
falk@leemia.de

SYSTEMVORRAUSSETZUNG:
Webserver mit PHP unterst�tzung (min. Version 5)

INSTALLATION:
Keine Installation erforderlich,
da keine Datenbank vorliegt und keine Konfoguration get�tigt werden muss.