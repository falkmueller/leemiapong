<div id="Field">
	<div id="middleLine"></div>
	<div id="pointsLeft">00</div>
	<div id="nameLeft">...</div>
	<div id="pointsRight">00</div>
	<div id="nameRight">...</div>
	<div id="ball"></div>
	<div id="paddleLeft" class="paddel"></div>
	<div id="paddleRight" class="paddel"></div>
</div>

<div style="clear: both;"></div>

<div class="Legend">
<div id="Player2Legend" class="PlayerLegend">
	<a onclick="paddleUp(2);" class="up" title="Up"></a>
	<a onclick="paddleDown(2)" class="down" title="Down"></a>
</div>

Steuerbar mir der Tastatur oder mit klick auf die Symbole.

<div id="PlayerLegend"  class="PlayerLegend">
	<a onclick="paddleUp(1)"  class="up" title="Up"></a>
	<a onclick="paddleDown(1)"  class="down" title="Down"></a>
</div>
</div>

<div style="clear: both;"></div>